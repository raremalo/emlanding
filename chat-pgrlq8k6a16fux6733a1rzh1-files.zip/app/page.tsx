"use client";

import { HeroSection } from "@/components/hero-section";
import { CourseDetails } from "@/components/course-details";
import { PricingSection } from "@/components/pricing-section";

export default function Home() {
  console.log("Home page rendering");
  
  return (
    <main className="min-h-screen">
      <HeroSection />
      <CourseDetails />
      <PricingSection />
    </main>
  );
}
